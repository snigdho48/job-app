import 'dart:ui';

const List<String> dropdownDate=['All','Today','1 day','2 day','5 day','1 week','1 month'];
const Color darkBlue=Color(0xFF1C58F2);
const Color searchBar=Color(0xFF1C58F2);
const Color btnBgLight=Color(0xFFF5F7FC);
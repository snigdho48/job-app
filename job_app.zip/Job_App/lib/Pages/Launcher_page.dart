import 'package:flutter/material.dart';
import 'package:job_app/Pages/Home_page.dart';

class LauncherPage extends StatelessWidget {
  static const String routeName = '/Launcher';

  const LauncherPage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.indigo,
      body: Column(
        children: const [
          _MainImageSection(),
          _Button()],
      ),
    );
  }
}

class _Button extends StatelessWidget {
  const _Button({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return TextButton(
      onPressed: () =>
          Navigator.pushReplacementNamed(context, HomePage.routeName),
      style: ElevatedButton.styleFrom(
        backgroundColor: Colors.white,
        minimumSize: const Size(200, 50), // NEW
// This is what you need!
      ),
      child: const Text('Start Browsing',
          style: TextStyle(
              color: Colors.blue, fontSize: 20, fontWeight: FontWeight.bold)),
    );
  }
}

class _MainImageSection extends StatelessWidget {
  const _MainImageSection({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Stack(
      alignment: Alignment.center,
      children: [
        Image.asset(
          'images/img.png',
          fit: BoxFit.fitWidth,
          alignment: FractionalOffset.topCenter,
        ),
        ClipRRect(
          borderRadius: BorderRadius.circular(250),
          child: Container(
            margin:
                EdgeInsets.only(top: MediaQuery.of(context).size.height / 2.05),
            color: Colors.indigo,
            width: MediaQuery.of(context).size.width / 1.2,
            height: MediaQuery.of(context).size.height / 7,
            child: Text(''),
          ),
        ),
        Positioned(
          bottom: MediaQuery.of(context).size.height / 35,
          child: Column(
            children: [
              const Text(
                'Climb higher with',
                style: TextStyle(color: Colors.white, fontSize: 30),
              ),
              SizedBox(
                height: MediaQuery.of(context).size.height / 40,
              ),
              const Text('JobSeek app',
                  style: TextStyle(color: Colors.white, fontSize: 30)),
              SizedBox(
                height: MediaQuery.of(context).size.height / 20,
              ),
            ],
          ),
        ),
      ],
    );
  }
}

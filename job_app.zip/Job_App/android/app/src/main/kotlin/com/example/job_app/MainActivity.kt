package com.example.job_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
